نشر موقع معيار

1) الفورم: سجّل في formspree.io (مجاني) واعمل Form جديد بإيميلك.
   هيديك رابط شكله https://formspree.io/f/xxxxxxx
   افتح index.html بأي محرر نصوص (Notepad) وابحث عن:  var FORM_ENDPOINT='';
   وحط الرابط بين العلامتين. (لو بتستخدم Web3Forms حط المفتاح في ACCESS_KEY بدلها.)

2) النشر: ادخل netlify.com/drop واسحب مجلد me3yar-site كله. هتاخد لينك في ثواني.
   (بدائل: GitHub Pages أو Cloudflare Pages.)

ملاحظة: جرّب ابعت طلب تجريبي بعد النشر وتأكد إنه وصل على إيميلك.
